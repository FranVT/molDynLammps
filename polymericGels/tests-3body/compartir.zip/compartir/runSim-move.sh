: '
    Script that runs the assembly procotol with given parameters.
'

#!/bin/bash

# Assign values to the independent variables
L=1;

# Assign computational parameters
dt=0.001;
seed1=3234;
seed2=6321;
seed3=2010;

steps=4500;

log_name="log-3btest.log";

# Assign significant decimals
cs=6;

# Compute values for dependent variables
Nsave=1; #${Nsave%.*};
NsaveStress=1; #${NsaveStress%.*};
Ndump=1; #${Ndump%.*};

# Assign values to file management variables
dir_data="/home/franvt/GitRepos/molDynLammps/polymericGels/tests-3body/data";
id="$(date +%F-%H%M%S)";
dir_save="$dir_data/$id";
mkdir "$dir_save";
mkdir "$dir_save/traj";
files_name=("system_assembly.fixf" "stress_assembly.fixf" "clust_assembly.fixf" "profiles_assembly.fixf" "traj_assembly.*.dumpf" "data.hydrogel" "system_shear.fixf" "stress_shear.fixf" "clust_shear.fixf" "profiles_shear.fixf" "traj_shear.*.dumpf" "strain-*.restart")

mpirun -np 1 lmp -sf omp -in in.tests-move.lmp -log $log_name -var L $L -var tstep $dt -var Nsave $Nsave -var NsaveStress $NsaveStress -var Ndump $Ndump -var steps $steps -var Dir $dir_save -var file1_name ${files_name[0]} -var file2_name ${files_name[1]} -var file3_name ${files_name[2]} -var file4_name ${files_name[3]} -var file5_name ${files_name[4]} -var file6_name ${files_name[5]};
